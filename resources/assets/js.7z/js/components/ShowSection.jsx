var React = require('react');
var ShowStore = require('../stores/ShowStore.jsx');

function getStateFromStores() {

  var tmp = ShowStore.showId();
  return {
      title: tmp.adress
  };
}

var ShowSection = React.createClass({

    getInitialState: function(){
        return {title:'Demo'};
    },

    flatChanged: function(){
        var flat = ShowStore.showId;
        this.setState({title:flat.adress});
    },

    componentDidMount: function(){
        ShowStore.addChangeListener(this._onChange);
    },

    componentWillUnmout: function(){
        ShowStore.removeChangeListener(this._onChange);
    },



    render: function (){
        return (
                <h1>This {this.state.title}</h1>
               );
    },

    _onChange: function() {
        this.setState(getStateFromStores());
    }

});

module.exports = ShowSection;
