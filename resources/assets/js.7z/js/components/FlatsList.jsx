/*** @jsx React.DOM */
var React = require('react');
var FlatsItem = require('./FlatsItem.jsx');

var FlatsList = React.createClass ({
    render: function() {
        var flats = this.props.flats.map(function(flat){
                return <FlatsItem key={flat.id}
                         adress={flat.adress} 
                         road={flat.road} 
                         price={flat.price}
                         id={flat.id}
                         sall={flat.sall}
                         room={flat.room}
                         floor={flat.floor}
                         phone={flat.phone}
                         fur={flat.fur}
                         fridge={flat.fridge}
                         metro={flat.metro}
                         />
            })
        return (
            <div className="flats-grid cf">
                {flats}
            </div>
        )
        }
    });

module.exports = FlatsList;
