var React = require('react');
var FlatsList = require('./FlatsList.jsx');
var FlatsForm = require('./FlatsForm.jsx');
var SearchStore = require('../stores/SearchStore.jsx');

function getStateFromStores() {
    return {
       flats: SearchStore.getAll(),
       page: 1,
       loadingFlag:false
    };
}

function handleScroll(){
    //this function will be triggered if user scrolls
    var windowHeight = $(window).height();
    console.log(windowHeight);
    var inHeight = window.innerHeight;
    console.log(inHeight);
    var scrollT = $(window).scrollTop();
    console.log(scrollT);
    var totalScrolled = scrollT+inHeight;
    console.log(totalScrolled);
    if(totalScrolled+600>windowHeight){  //user reached at bottom
        console.log('scroll');
    }
}


var SearchSection = React.createClass({

    getInitialState: function(){
        return getStateFromStores();    
    },

    componentDidMount: function(){
        window.addEventListener("scroll", handleScroll());
        SearchStore.addChangeListener(this._onChange);
    },

    componentWillUnmout: function(){
        SearchStore.removeChangeListener(this._onChange);
    },
    render: function(){
            return ( 
                <div>
                    <div className="form-section">
                        <FlatsForm />
                    </div>
                    <div className="search-section">
                        <FlatsList flats={this.state.flats} />
                    </div>
                </div>
            );
        },

        _onChange: function() {
        this.setState(getStateFromStores());
    }
    });

module.exports = SearchSection;
