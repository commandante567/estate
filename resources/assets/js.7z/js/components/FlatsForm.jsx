/*** @jsx React.DOM */
var React = require('react');
var FlatServerActionCreators = require('../actions/FlatServerActionCreators.jsx');


var FlatsForm = React.createClass ({
   
    getInitialState: function() {
        return {road:'',room:''};
        },

    _handleRoad: function(event){
            this.setState({road: event.target.value.trim()}, function(){
                FlatServerActionCreators.searchFlat(this.state);
                });
        },

    _handleRoom: function(event) {
            event.preventDefault();
            this.setState({room: event.target.value.trim()}, function(){
                FlatServerActionCreators.searchFlat(this.state);
                });
        },

    render: function() {
        return (
        <div className="flat-form">
            <div className="form-control">
                <input type="text" ref="searchInput" placeholder="Введите станцию метро" value={this.state.road} onChange={this._handleRoad}/>
            </div>
        </div>
        );
    }
    });

module.exports = FlatsForm;
