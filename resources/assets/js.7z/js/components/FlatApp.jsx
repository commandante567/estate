/*** @jsx React.DOM */
var React = require('react');
var SearchSection = require('./SearchSection.jsx');
var ShowSection = require('./ShowSection.jsx');

var FlatApp = React.createClass({

    render: function() {
        return (
            <div className="flats-app">
                <div className="left-section">
                    <SearchSection />
                </div>
                <div className="right-section">
                    <ShowSection />
                </div>
            </div>
        );
    }
});

module.exports = FlatApp;
