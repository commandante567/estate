/*** @jsx React.DOM */
var React = require('react');
var FlatServerActionCreators = require('../actions/FlatServerActionCreators.jsx')


var FlatsItem = React.createClass({
    
    render:function(){
        return (
            <div className="flat-item">
                <div className="flat-title cf">
                    <div className="flat-address">
                        <h3>
                           <a href={'#' +this.props.id} onClick={this._handleMoreClick}> 
                        <span>{this.props.adress}</span><span className="flat-price">{this.props.price}</span>
                            </a>
                        </h3>
                    </div>
                </div>
                <div className="flat-meta cf">
                    <div className="flat-road">
                    <p><i className="fa fa-subway"></i>
                        {this.props.road}</p>
                    </div>
                    <div className="flat-room">
                        <p><span>Комнат: {this.props.room},</span> <span>Площадь: {this.props.sall},</span> <span>Этаж: {this.props.floor}</span></p>
                    </div>
                    <div className="flat-icons">
                        <ul>
                            <li className={'icon' + this.props.phone}>
                                <i className="fa fa-phone"></i>
                            </li>
                            <li className={'icon' + this.props.fur}>                            
                                <i className="fa fa-hospital-o"></i>

                            </li>
                            <li className={'icon' + this.props.fridge}>
                                <i className="fa fa-hospital-o"></i>
                            
                            </li>
                            <li className={'icon' + this.props.metro}>
                                <i className="fa fa-hospital-o"></i>
                            
                            </li>
                        </ul>
                    </div>
                </div>
                <div className="flat-link">
                    <span></span>
                </div>
            </div>
        );
        },

        _handleMoreClick: function(event) {
            FlatServerActionCreators.receiveId(this.props.id);
        }

    });


module.exports = FlatsItem;
