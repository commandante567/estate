var FlatConstants = require('../constants/FlatConstants.jsx');
var FlatServerActionCreators = require('../actions/FlatServerActionCreators.jsx');
var FlatShowActionCreators = require('../actions/FlatShowActionCreators.jsx');

var FlatListActionCreators = require('../actions/FlatListActionCreators.jsx');

var ServerApiUrl = FlatConstants.ServerApiUrl;

module.exports = {

    getAllFlats: function(){

        $.ajax({
            url: ServerApiUrl.URL,
        dataType: 'json',
        success: function(data) {
            FlatServerActionCreators.receiveAll(data);
        }.bind(this),
        error: function(xhr, status, err) {
            console.error(ServerApiUrl.URL, status, err.toString());
        }.bind(this)
        });
    },


    getFlatId: function(id){
        $.ajax({
            url: ServerApiUrl.ID,
        dataType: 'json',
        data:{id:id},
        success : function(flatI){
            FlatShowActionCreators.getFlat(flatI);
        }.bind(this),
        error:function(xhr, status,err){
            console.error(ServerApiUrl.URL, status, err.toString());
        }.bind(this)
        });

    },

    searchFlat: function(query) {
        console.log(query);
        $.ajax({
            url: ServerApiUrl.URL,
            dataType: 'json',
            data:{road:query.road,
                  room:query.room,  
                    },
            success: function(data) {
                FlatListActionCreators.showFlats(data);
        }.bind(this),
        error: function(xhr, status, err) {
            console.error(ServerApiUrl.URL, status, err.toString());
        }.bind(this)
            });
    }

};

