var FlatAppDispather = require('../dispather/FlatAppDispather.jsx');
var FlatConstants = require('../constants/FlatConstants.jsx');

var MicroEvent = require('../microevent.js')

var ActionTypes = FlatConstants.ActionTypes;


var CHANGE_EVENT = 'change';

var SearchStore = {
   
    flats: {},
   
    flatShow:{},

    getAll: function() {
        return this.flats.data;
        },
    
    showId: function() {
        return this.flatShow;
        },

    addChangeListener: function(callback) {
    this.on(CHANGE_EVENT, callback);
  },

  removeChangeListener: function(callback) {
    this.removeListener(CHANGE_EVENT, callback);
  },
};

SearchStore.dispatchToken = FlatAppDispather.register(function(action){
   
    switch(action.type){

        case ActionTypes.RECEIVE_RAW_FLATS:

            SearchStore.flats = action.rawFlats;

            break;

        case ActionTypes.SHOW_LIST :
            
            SearchStore.flats = action.flatItems;

            SearchStore.trigger('change');

            break;

        default:

    }
    return true; // Needed for Flux promise resolution

});

MicroEvent.mixin(SearchStore);

module.exports = SearchStore;
