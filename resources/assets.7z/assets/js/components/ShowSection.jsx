var React = require('react');
var ShowStore = require('../stores/ShowStore.jsx');
var ShowMap = require('./ShowMap.jsx');

function getStateFromStores() {

  var tmp = ShowStore.showId();
  return tmp  ;
}

function format(n, currency) {
    n = parseInt(n);
    var t =  n.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1 ");
    return t.substring(0, t.length-3)  + " " + currency;
}

var ShowSection = React.createClass({

    getInitialState: function(){
        return ShowStore.showId();
    },

    flatChanged: function(){

    },

    componentDidMount: function(){
        ShowStore.addChangeListener(this._onChange);
    },

    componentWillUnmout: function(){
        ShowStore.removeChangeListener(this._onChange);
    },



    render: function (){
        var price = format(this.state.price,'руб.');
        return (
                 <div className="item">
                 <div className="item-header">
                    <div className="header-logo">
                      <img src=""/>
                    </div>
                  </div>
                  <div className="item-main cf">
                    <div className="cf">
                    <div className="item-info">
                    <div className="item-title">
                      <h1>{this.state.adress}</h1>
                    </div>
                    <div className="item-road">
                      <h2>{this.state.road}</h2>
                    </div>
                      <table>
                        <tr>
                          <td>Объект</td>
                          <td></td>
                        </tr>
                        <tr>
                          <td>Цена</td>
                          <td>{price}</td>
                        </tr>
                        <tr>
                          <td>Комнаты</td>
                          <td>{this.state.room}</td>
                        </tr>
                        <tr>
                          <td>Общая площадь</td>
                          <td>{this.state.sall}</td>
                        </tr>
                        <tr>
                          <td>Этаж</td>
                          <td>{this.state.floor}</td>
                        </tr>
                      </table>
                      <div className="flat-icons">
                        <ul>
                            <li className={'icon' + this.props.phone}>
                                <i className="fa fa-phone"></i>
                            </li>
                            <li className={'icon' + this.props.fur}>                            
                                <i className="fa fa-hospital-o"></i>

                            </li>
                            <li className={'icon' + this.props.fridge}>
                                <i className="fa fa-hospital-o"></i>
                            
                            </li>
                            <li className={'icon' + this.props.metro}>
                                <i className="fa fa-hospital-o"></i>
                            
                            </li>
                        </ul>
                    </div>
                    </div>
                    <div className="item-meta">
                      <div className="item-pic">
                        <img src="http://lorempixel.com/344/200"/>
                      </div>
                      <div className="item-contacts">
                        <table>
                          <tr>
                            <td><a href="#"> <i className="fa fa-phone"></i>992-12-12</a></td>
                            <td><a href="#"><img src="/img/icons/Envelope.png" alt="Написать" title="Написать"/></a></td>
                            <td><a href="#"><img src="/img/icons/skype.png" alt="Skype" title="Skype"/></a></td>
                          </tr>
                          <tr>
                            <td colSpan="3"><a href="#">Обратный звонок</a></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                    </div>
                    <div className="item-map">
                        <ShowMap 
                            mapCenterLat = {this.state.lat} 
                            mapCenterLng = {this.state.long}
                        />
                    </div>
                  </div>
                  </div>
               );
    },

    _onChange: function() {
        this.setState(getStateFromStores());
    }

});

module.exports = ShowSection;
